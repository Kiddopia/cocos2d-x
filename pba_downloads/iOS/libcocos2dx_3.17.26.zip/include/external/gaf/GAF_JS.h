#include <cocos2d.h>
#include "GAF.h"
#include "GAFMovieClip.h"
#include "GAFTextField.h"
#include "GAFAnimationSequence.h"
using std::string;

#ifdef __gaf_h__ // Will be included only after jsb_gaf.h
#include "js_gaf_manual_conversions.h"
#endif
