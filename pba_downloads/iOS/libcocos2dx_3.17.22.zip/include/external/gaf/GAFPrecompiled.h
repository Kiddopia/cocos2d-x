#pragma once

#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include <limits.h>
#include <ctype.h>
#include <string>
#include <vector>
#include <stack>

#include <assert.h>
#include <algorithm>

#include <cocos2d.h>

#include "GAFMacros.h"
